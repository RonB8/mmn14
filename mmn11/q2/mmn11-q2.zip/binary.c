//
// Created by user on 10/11/2022.
//
//
// Created by user on 10/11/2022.
#include <stdio.h>
#include <stdlib.h>
void reversePrint(char *s);
int sizeArr(char *arr);


void asBinary(int num)
{
    int n=num;
    int i=0;
    char res[100];
    while(n>0)
    {
        res[i] = (n%2 == 0)? '0': '1';
        n/=2;
        i++;
    }
    res[i] = '\0';
    reversePrint((res));
}

void reversePrint(char *s)
{
    int length = sizeArr(&(*s));
    int i = length-1;
    while(i>=0)
    {
        printf("%c", *(s+i));
        i--;
    }
    printf("\n");
}

int sizeArr(char *arr)
{
    int i=0;
    while (*(arr+i)!='\0')
    {
        i++;
    }
    return i;
}

int *get_bits(int n, int bitswanted){
    int *bits = malloc(sizeof(int) * bitswanted);

    int k;
    for(k=0; k<bitswanted; k++){
        int mask =  1 << k;
        int masked_n = n & mask;
        int thebit = masked_n >> k;
        bits[k] = thebit;
    }

    return bits;
}
// for example: printBits(sizeof(num), &num);
void printBits(size_t const size, void const * const ptr)
    {
        unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;
    printf("By binary base: ");
    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}


void printBits_String_int(size_t const size, void const * const ptr, char s[3], int n)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;

    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }

    printf(" = %s = %d\n", s, n);

}