//
// Created by user on 07/11/2022.
//

#ifndef Q1_DATA_H
#define Q1_DATA_H

#endif //Q1_DATA_H
#define SIZE 80
