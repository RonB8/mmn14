//
// Created by user on 07/11/2022.
//
#include <stdio.h>
//check if the string is in rising order
int riseStr(char x, char y, char z)
{
    return (x+1 == y && y+1 == z);
}
//calculate the length of array
int arrLen(char *str)
{
    int i=0;
    while (*(str+i)!='\0')
        i++;
    return i;
}

int isAlphabet(int argument)
{
    return 'A' <= argument && argument <= 'z';
}
//Replaces the middle characters of the ordered substring, and replaces them with '-'.
void shortStr(char *str) {
    int length = arrLen(&(*str));
    int i;
    char temp = (*(str));
    char before, current, after;
    //The loop marks the characters to be changed.
    for (i = 1; i<length; i++) {
        //The condition in before takes into account a character that is part of the ascending substring, but is marked.
        before = ((*(str+i-1)) == '-' || (*(str+i-1)) =='\0')? temp: (*(str+i-1));
        current = (*(str+i));
        after = (*(str+i+1));
        if (riseStr(before, current, after) && isAlphabet(current)) {
            temp = (*(str + i)); //Save the character for the test in the next iteration.
            *(str + i) = ((*(str+i-1))=='-' || (*(str+i-1))=='\0')? '\0' :'-';
        }
    }
    int shiftBack=0;
    while(*(str+shiftBack)!='\0' && *(str+shiftBack)!='\0')
        shiftBack++;
    for(i=shiftBack+1; i<length; i++)
    {
        current = *(str+i);
        if(current != '\0')
        {
            *(str+i) = '\0';
            *(str+shiftBack) = current;
            shiftBack++;
        }
    }
}