#include <stdio.h>
#include "data.h"
void shortStr(char* str[]);

int main() {
    char str[SIZE]; //The string
    printf("Insert a string:\n");
    scanf("%s", &str);
    printf("The original string is: %s\n", str);
    shortStr(&str[0]);
    printf("The shortened string is: %s\n", str);
    return 0;
}
