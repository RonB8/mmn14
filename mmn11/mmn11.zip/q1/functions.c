#include <stdio.h>
#define SIZE 80 /* The maximum size of string*/

/* Checks if the characters of the string are arranged in ascending order. */
int riseStr(char x, char y, char z)
{
    return (x+1 == y && y+1 == z);
}
/* Calculate the length of the string.*/
int arrLen(char str[SIZE])
{
    int i=0;
    while (str[i]!='\0')
        i++;
    return i;
}
/* Checks whether the received character is a letter. */
int isAlphabet(int argument)
{
    return 'A' <= argument && argument <= 'z';
}
/* Replaces the middle characters of the ordered substring, and replaces them with '-'. */
void shortStr(char str[SIZE]) {
    int length = arrLen(str);
    int i;
    char temp = str[0];
    char before, current, after;
    /* The loop marks the characters to be changed. */
    for (i = 1; i<length; i++) {
        /* The condition in before takes into account a character that is part of the ascending substring, but is marked. */
        before = (str[i-1] == '-' || str[i-1] =='\0')? temp: str[i-1];
        current = str[i];
        after = str[i+1];
        if (isAlphabet(before) && isAlphabet(after) && riseStr(before, current, after)) {
            temp = current; /* Save the character for the test in the next iteration. */
            str[i] = (str[i-1] == '-' || str[i-1] == '\0')? '\0' :'-';
        }
    }
    int shiftBack=0;
    /* Places shiftback at the first place where '\0' appears. */
    while(str[shiftBack]!='\0')
        shiftBack++;
        
    for(i=shiftBack+1; i<length; i++)
    {
        current = str[i];
        if(current != '\0')
        {
            str[i] = '\0';
            str[shiftBack] = current;
            shiftBack++;
        }
    }
}
