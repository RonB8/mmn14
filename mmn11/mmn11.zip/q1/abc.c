#include <stdio.h>
#define SIZE 80 /* The maximum size of string*/

void shortStr(char str[SIZE]);

int main() {
    char str[SIZE];
    printf("Insert a string:\n");
    fgets(str, SIZE, stdin);
    printf("The original string is: %s\n", str);
    shortStr(str);
    printf("The shortened string is: %s\n", str);


	
    return 0;
}
