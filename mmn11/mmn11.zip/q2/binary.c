#include <stdio.h>
#include <stdlib.h>


int sizeArr(char *arr)
{
    int i=0;
    while (*(arr+i)!='\0')
    {
        i++;
    }
    return i;
}


void printBits(size_t const size, void const * const ptr)
    {
        unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;
    printf("By binary base: ");
    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}

