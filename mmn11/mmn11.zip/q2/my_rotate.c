#include <stdio.h>

/*This function performs a 'b' bits rotation on the 'a' parameter.*/

void printInAllBase(int num); /* Prints the number by base 16, 10, 8, and 2. */
unsigned int my_rottate(unsigned int a, int b); /*The function that rotates the bits of the number. */

int main() {
    int steps; /* The number of the bits to move */
    int num; /* The number of prameter a */
    printf("Hello, the program below performs a rotation of b bits on parameter a\n"
           "Enter a number:\n");
    scanf("%i", &num);
    printf("How many bits to shift?\npositive number - shift to the right\nnegative number - shift to the left\n");
    scanf("%i", &steps);
    printf("The original number: \n");
    printInAllBase(num);
    int res =  my_rottate(num, steps);
    printf("\nThe number after shift of %i bits to the %s: \n", ((steps<0)?(-steps): steps), ((steps<0)? "left": "right"));
    printInAllBase(res);
    return 0;
}
