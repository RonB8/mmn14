#include <stdio.h>
#define BITS_PER_BYTE 8

void printBits(size_t const size, void const * const ptr); /* The function prints number according to binary representation. */

unsigned int my_rottate(unsigned int a, int b) /* Rotates the bits of the number. */
{
    /*Without limiting the generality, the description will refer to the situation where the rotation is to the right.*/
    int steps = b;
    int res = a; /*result*/
    /*Turns the right 'steps' bits to '1' */
    int helper = ~((~0)<<steps);
    /*The right 'steps' bits of 'res'*/
    int rightestStepsBits = (res&helper);
    /*The right 'steps' bits are shifted to the left edge*/
    rightestStepsBits =  rightestStepsBits<<(sizeof(steps)*BITS_PER_BYTE-steps);
    res = res>>steps;
    /*Adds to 'res' the 'steps' bits that "disappeared" from the right side, to the left side*/
    res = res|rightestStepsBits;
    return res;
}

void printInAllBase(int num)
{
    printf("By decimal base: %i\n", num); /* base 10 */
    printBits(sizeof(num), &num); /* base 2 */
    printf("By octal base: %o\n", num); /* base 8 */
    printf("By hexadecimal base: %X\n", num); /* base 16 */
}
